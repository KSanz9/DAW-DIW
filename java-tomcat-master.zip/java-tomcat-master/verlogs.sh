#!/bin/bash

tail -f /opt/tomcat/apache-tomcat-9.0.27/logs/catalina.out


